<?php
	// configuration
	require("../includes/config.php");
	// if form was submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$stock = lookup($_POST["symbol"]);
		// likewhise $stock wil not be false, but empty or another error
		if($stock === false){
			apologize("There seems to be an error with the stock you entered ! ");
		}else{
			// lookup returned an associative array of symbol, name and price
			print("Symbol : " . $stock["symbol"]);
			print("Name : " . $stock["name"]);
			print("Price : " . number_format($stock["price"], 4);
		}
	}else{
		//render("quote_form.php", ["title" => "Looking up a quote"]);
	}
?>