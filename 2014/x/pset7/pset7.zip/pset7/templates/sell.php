<?php



?>

<?php 

	/* 
	For selling we need a few things
	First we need to make a list of every stocks the id has 
	If the user submit, we need to do our delete and update queries
	*/



    // configuration
	require("../includes/config.php");
	// if form was submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){

		query("DELETE FROM stocks WHERE id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
		query("UPDATE users SET cash = cash + 500 WHERE id = ?", $_SESSION["id"]);

		
	}else{
		render("sell_form.php", ["title" => "Selling", "stock" => $stock]);
	}



?>