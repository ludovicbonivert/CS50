<?php 
	if(isset($symbol)){
		echo "it is";
	}
?>
<form action="quote.php" method="post">
	<fieldset>
		<div class="form-group">
			<input autofocus class="form-control" name="symbol" placeholder="Symbol" type="text"/>
		</div>
		<div class="form-group">
			<button type="submit" class="btn btn-default">Register</button>
		</div>
	</fieldset>
</form>